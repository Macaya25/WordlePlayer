Entrega Proyecto 1 
Andres Macaya

El archivo principal es player.py el resto de scripts son para organizar de mejor manera el codigo.
Ejecutar solo con:

python player.py

No recibe argumentos.
Adjunto tambien el diagrama en formato draw.io y pdf. Me disculpo por cómo quedo el pdf, dividido en 2 páginas.
